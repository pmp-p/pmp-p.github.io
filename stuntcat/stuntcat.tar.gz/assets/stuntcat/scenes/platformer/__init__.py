"""
Platformer module.
"""
