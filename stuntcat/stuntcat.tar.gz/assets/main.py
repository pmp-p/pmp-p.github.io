import sys
import asyncio

import pymunk
import pygame

from stuntcat.game import Game
asyncio.run( Game().mainloop() )

